import React, { useState } from 'react'
import { Customer1 } from './Customer1';


export const Customer_Details = (props) => {
// alert(props.bag3)
    // const [t1,sret1]=useState(0)
    // sret1(Number(t1)+Number(props.bag3))
    // for(var i of props.bag3)
    // {
    // //  alert(i.Sprice3)
    //  sret1(Number(t1)+Number(i.Sprice3))
    // }
    var d = new Date();
    const [c_name, Sc_name] = useState();
    const [c_Mobile, Sc_Mobile] = useState();
    const [c_Address, Sc_Address] = useState();
    const CUDTEMER_DETAILS = (q) => {
      Sc_name( props.bag1[q.target.value].name)
      Sc_Mobile( props.bag1[q.target.value].mobile)
      Sc_Address( props.bag1[q.target.value].address)
    }
    function Save(){

    }
    return (
        <div>
            <h4>Customer Details</h4>

            <select className='jjjj' onChange={CUDTEMER_DETAILS}>
                <option>Select</option>
                {
                    props.bag1.map((elem, index) => (
                       <Customer1
                            name2={elem.name}
                            index2={index}
                            />
                    ))
                }
            </select>

            <table>
                <tr>
                    <th>Customer Name :</th>
                    <td>{c_name}</td>
                </tr>
                <tr>
                    <th>Customer Mobile :</th>
                    <td>{c_Mobile}</td>
                </tr>
                <tr>
                    <th>Customer Address :</th>
                    <td>{c_Address}</td>
                </tr>



            </table>
            <h4 className='ioio'>Bill Date</h4>
            <input value={d.toString()} className='Amaunt'></input>
            <h4 className='ioio'>Payment Deatails</h4>
            <select className='jjjj'>
                <option>Select</option>
                <option>Cash</option>
                <option>Online</option>
            </select>
            <input value={props.bag3} className='Amaunt my-2'></input>
            <h4 className='ioio'>Bill Deatails</h4>
            <div className='tamount'>
                <h5>Total Ammount</h5>
                <h3>{Math.round(props.bag3)}</h3>
            </div>
            <div id='kjkj'>
                <button onClick={Save} className='bg-success'>Save</button>
                <button className='bg-warning'>Clear</button>
            </div>

        </div>
    )
}
