import React from 'react'

export const Select = (props) => {
    return (
        <option className='aaaa uyuy' value={props.index1}>{props.name1+" ... "+props.sale_price+" रु"}</option>
    )
}
