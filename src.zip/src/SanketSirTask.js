import React, { useState } from 'react'
import Data from './Task.json'
import Customer from './Customer.json'
import { Select } from './Component/Select'
import { Customer1 } from './Component/Customer1'
import { Product_list1 } from './Product_list1'
import { Customer_Details } from './Component/Customer_Details'
export const SanketSirTask = (props) => {
  const [product, Setproduct] = useState([])
  const [product_list, Setproduct_list] = useState([])
  const [AA, SetAA] = useState(0)
  const [DV, SetDV] = useState(0)
  const [QTY3, setQTY3] = useState(0)
  const [ind, Setind] = useState(0)
  

  const ADD = (q) => {
    // alert(q)
    // Setproduct_list([{...product_list,name:q.data.name}])
  }
  // const [ind, Setind] = useState(0)
  const Product_Select = (q) => {
    Setind(q.target.value)
     SetAA(Number(AA)+Number(Data[q.target.value].SalePrice))
     SetDV(Number(DV)+Number(Data[q.target.value].price))
     setQTY3(Number(QTY3)+1)
    Setproduct_list([...product_list, {
      name3: Data[q.target.value].name,
      price3: Data[q.target.value].price,
      Sprice3: Data[q.target.value].SalePrice,
      count3: Data[q.target.value].count


    }])
  }

  const [Qty, SetQty] = useState()
  const [FTotal, SetTotal] = useState()
  const [Discount, SetDiscount] = useState()
  const [Fbill, SetFbill] = useState()
  const [custmer_bill, Setcustmer_bill] = useState(0)

  const [PRO_total, SetPRO_total] = useState([])
 
  const Total = (a, b) => {
    // alert("rr")
    PRO_total.splice((ind), 1, ((Number(a) * Number(b))))
     Setcustmer_bill((Number(a) * Number(b)))
props.bag1(AA,DV,QTY3)
    return (Number(a) * Number(b))

  }


  let [Count, Setcount] = useState([55, 56])
  const Minus = (q) => {
    setQTY3(Number(QTY3)-1)
    SetAA(Number(AA)-Number(product_list[q.target.value].Sprice3))
    SetDV(Number(DV)-Number(product_list[q.target.value].price3))
    product_list.splice(q.target.value, 1, {
      name3: product_list[q.target.value].name3,
      price3: product_list[q.target.value].price3,
      Sprice3: product_list[q.target.value].Sprice3,
      count3: (Number(product_list[q.target.value].count3) - 1)
    })
    console.log(product_list)
    // Setcount(Count-1)

  }

  const Plus = (q) => {
    // alert(Number(Number(product_list[q.target.value].count3) + 1)*Number(product_list[q.target.value].Sprice3))
    setQTY3(Number(QTY3)+1)
    SetAA(Number(AA) +Number(product_list[q.target.value].Sprice3))
    SetDV(Number(DV) +Number(product_list[q.target.value].price3))
    // SetDV(Number(Number(product_list[q.target.value].count3) + 1)*Number(product_list[q.target.value].price3))
    product_list.splice(q.target.value, 1, {
      name3: product_list[q.target.value].name3,
      price3: product_list[q.target.value].price3,
      Sprice3: product_list[q.target.value].Sprice3,
      count3: (Number(product_list[q.target.value].count3) + 1)
    })
    Setproduct_list(product_list)
  }



  const Delete = (q) => {
    product_list.splice(q.target.value, 1)
    product_list.splice((product_list.length + 1), 0,)

  }
  const Save = (q) => {
  }

  return (
    <div >
      <div className='row'>
        <div className='col-lg-8 left_column'>
          <h4>Produt Details</h4>
          <select className='jjjj'  onChange={Product_Select}>
            <option className='uyuy'>Select</option>
            {
              Data.map((data, index) => (
                <Select
                  name1={data.name}
                  price1={data.price}
                  sale_price={data.SalePrice}
                  index1={index}
                />
              ))
            }
          </select>

          <Product_list1
            bag1={product_list}
            bag2={Total}
            bag3={Minus}
            bag4={Plus}
            bag5={Count}
            bag6={Delete}

          />





        </div>
        <div className='col-lg-4 right_column'>
          <Customer_Details
            bag1={Customer}
            bag2={custmer_bill}
            bag3={AA}
          />

        </div>

      </div>
    </div>



  )
}
